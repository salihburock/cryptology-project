import os
from flask import Flask, render_template, request


app = Flask(__name__, static_folder='static')

@app.route('/')
def index():
    input = request.args.get('input')
    open('toEncrypt.txt','w+').write(input)
    os.system('python funcs.py -c')
    if os.fileexist('ftest.mp4'):
        return render_template('template.html')
    else:
        return render_template('trysgain.html')
if __name__ == "__main__":
    app.run(port=8081,debug=1)